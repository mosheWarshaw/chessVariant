"use strict";
export {emptyAndNotOpaque};
/*These cells can't have pieces put on them. I didn't remove them because the board would no
longer be square, but I made them opaque so it's clear that they can't be used.*/
let opaqueCells = [1, 2, 3, 12, 13, 23, 99, 109, 110, 119, 120, 121];
//blueOfCell is the blue number of the cell. it's the id.
function emptyAndNotOpaque(cellsBlue){
    let empty;
    /*checking if the src attr is an empty string checks if it has an image of a piece being displayed,
    which is the same as finding out if the cell is empty.*/
    if($("#" + cellsBlue + " img").attr("src") == ""){
        empty = true;
    }
    else{
        empty = false;
    }

    let notOpaque;
    if($("#" + cellsBlue).hasClass("opaqueCell")){
        notOpaque = false;
    }
    else{
        notOpaque = true;
    }

    return empty && notOpaque;
}