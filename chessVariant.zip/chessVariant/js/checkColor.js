export{checkColor};
/*this is used to ensure that the user isn't trying to put their piece in a cell where there is a piece that is its
own color.*/
function checkColor(piecesColor, secondCellsPieceColor){
    if((piecesColor == "white"  && secondCellsPieceColor == "black") || (piecesColor == "black" &&
        secondCellsPieceColor == "white")){
        return true;
    }
    else if((piecesColor == "white" && secondCellsPieceColor == "white") || (piecesColor == "black"
        && secondCellsPieceColor == "black")){
        return false;
    }
}