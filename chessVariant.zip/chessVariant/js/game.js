"use strict";
export {Game};
import {pickUpKingEtc, pickUpPawn} from "./pickUpKingEtcOrPawn.js"
import {pickUpRookOrBishop} from "./pickUpRookOrBishop.js"
import {putPieceDown} from "./putPieceDown.js";
import {screenSecondCell} from "./screenSecondCell.js";

const KING_ARR = [1, -1, 10, -10, 11, -11, 12, -12];
const PRINCE_ARR = [2, -2, 20, -20, 22, -22, 24, -24];
const WHITE_PAWN_ARR = [-10, -11, 1, 10];
const BLACK_PAWN_ARR = [10, 11, -1, -10];

class Game{
    #clickTurn;
    #colorsTurn;
    #valid;
    #piece;
    #piecesColor;
    /*firstCellsBlue refers to the blue cell number of the cell that the piece is being picked up from.
    secondCellsBlue is the blue cell number of the cell that the user wants to put the piece down in.*/
    #firstCellsBlue;
    //The red number of the cell the piece was picked up from.
    #firstCellsRed;
    #secondCellsBlue;
    #secondCellOptions;
    constructor(){
        /*A user's move is separated into 2 turns of clicking. The first turn is the user clicking on
        a cell that holds a piece they want to move. The piece is picked up, and cells that the user
        can put the piece down in get a cyan border. The user's second turn is clicking on the cell
        that the user wants to place the piece in.*/
        this.#clickTurn = "pickUp";
        //white goes first.
        this.#colorsTurn = "white";
        this.#valid = false;
    }
    pickUp(td){
        this.#firstCellsBlue = parseInt($(td).attr("id"));
        this.#firstCellsRed = parseInt($(td).attr("title"));
        this.#piece = $("#" + this.#firstCellsBlue + " img").attr("src");
        this.#piecesColor = $("#" + this.#firstCellsBlue + " img").attr("class");
        if(this.#piecesColor == this.#colorsTurn){
            $("#" + this.#firstCellsBlue + " img").removeClass(this.#piecesColor);
            $("#" + this.#firstCellsBlue + " img").attr("src", "");

            if(this.#piece == "images/whiteKingCropped.png" || this.#piece == "images/blackKingCropped.png"){
                /*secondCellOptions is redefined before each function so that it doesn't
                hold any of the cell numbers from the previous turn.*/
                this.#secondCellOptions = [];
                this.#secondCellOptions = pickUpKingEtc(this.#secondCellOptions, this.#firstCellsBlue,
                    this.#piecesColor, KING_ARR, false);
            }
            else if(this.#piece == "images/whitePrinceCropped.png" || this.#piece == "images/blackPrinceCropped.png"){
                this.#secondCellOptions = [];
                this.#secondCellOptions = pickUpKingEtc(this.#secondCellOptions, this.#firstCellsBlue,
                    this.#piecesColor, PRINCE_ARR, false);
            }
            else if(this.#piece == "images/whiteGeneralCropped.png" || this.#piece == "images/blackGeneralCropped.png"){
                this.#secondCellOptions = [];
                //The general can move like a king and prince.
                this.#secondCellOptions = pickUpKingEtc(this.#secondCellOptions, this.#firstCellsBlue,
                    this.#piecesColor, KING_ARR, false);
                /*There are probably going to be elements in secondCellOptions from the function
                call above, so when it's passed in below it's going to be returned with new
                elements added onto after those.*/
                this.#secondCellOptions = pickUpKingEtc(this.#secondCellOptions, this.#firstCellsBlue,
                    this.#piecesColor, PRINCE_ARR, false);
            }
            //The black and white pawns have different rules of movement, so they're separate.
            else if(this.#piece == "images/whitePawnCropped.png") {
                this.#secondCellOptions = [];
                this.#secondCellOptions = pickUpPawn(this.#secondCellOptions, this.#firstCellsBlue, WHITE_PAWN_ARR,
                    "black");
            }
            else if(this.#piece == "images/blackPawnCropped.png"){
                this.#secondCellOptions = [];
                this.#secondCellOptions = pickUpPawn(this.#secondCellOptions, this.#firstCellsBlue, BLACK_PAWN_ARR,
                    "white");
            }
            else if(this.#piece == "images/whiteShieldCropped.png" || this.#piece == "images/blackShieldCropped.png"){
                    this.#secondCellOptions = [];
                    //The shield moves the same as the king so the same array can be passed in.
                    this.#secondCellOptions = pickUpKingEtc(this.#secondCellOptions, this.#firstCellsBlue,
                        this.#piecesColor, KING_ARR, true);
            }
            else if(this.#piece == "images/whiteRookCropped.png" || this.#piece == "images/blackRookCropped.png"){
                this.#secondCellOptions = [];
                this.#secondCellOptions = pickUpRookOrBishop(this.#secondCellOptions, this.#firstCellsBlue, this.#piece,
                    this.#piecesColor);
            }
            else if(this.#piece == "images/whiteBishopCropped.png" || this.#piece == "images/blackBishopCropped.png"){
                this.#secondCellOptions = [];
                //The bishop can move like a king and the way a bishop moves in traditional chess.
                this.#secondCellOptions = pickUpKingEtc(this.#secondCellOptions, this.#firstCellsBlue,
                    this.#piecesColor, KING_ARR, false);
                this.#secondCellOptions = pickUpRookOrBishop(this.#secondCellOptions, this.#firstCellsBlue, this.#piece,
                    this.#piecesColor);
            }
            this.#clickTurn = "putDown";
        }
    }
    putDown(td){
        this.#secondCellsBlue = parseInt($(td).attr("id"));

        /*The user can put a piece down in the cell it was picked up from and not have this count
         as the user's move, because i want the user to be able to see the cyan borders and
         where it could go without having to then move it.*/
        if(this.#firstCellsBlue == this.#secondCellsBlue){
            putPieceDown(this.#secondCellsBlue, this.#piece, this.#piecesColor);
            $("td").removeClass("cyanBorder");
            this.#clickTurn = "pickUp";
        }
        else{
            this.#valid = screenSecondCell(this.#secondCellsBlue, this.#secondCellOptions);

            /*Since the following code is not run unless the user clicks on a valid second cell,
            it remains the second turn, and the user is still holding the piece they picked up.
            The user just has to click on a valid cell to put it in (and it doesn't matter how
            many times the user clicks on invalid cells).*/
            if(this.#valid){
                putPieceDown(this.#secondCellsBlue, this.#piece, this.#piecesColor);
                $("td").removeClass("cyanBorder");
                this.#clickTurn = "pickUp";
                if(this.#piecesColor == "white"){
                    this.#colorsTurn = "black";
                }
                else{
                    this.#colorsTurn = "white";
                }
                this.#valid = false;
            }
        }
    }
    getClickTurn(){
        return this.#clickTurn;
    }
}