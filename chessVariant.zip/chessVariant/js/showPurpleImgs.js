"use strict";
let purpleArr = [["", 7, "images/purpleRookCropped.png"], ["", 8, "images/purpleBishopCropped.png"],
    ["", 10, "images/purpleGeneralCropped.png"], ["", 20, "images/purplePrinceCropped.png"],
    ["", 37, "images/purpleBishopCropped.png"], ["", 41, "images/purpleRookCropped.png"],
    ["", 44, "images/purpleRookCropped.png"], ["", 55, "images/purpleBishopCropped.png"],
    ["", 61, "images/purplePrinceCropped.png"], ["", 67, "images/purpleBishopCropped.png"],
    ["", 78, "images/purpleRookCropped.png"], ["", 81, "images/purpleRookCropped.png"],
    ["", 85, "images/purpleBishopCropped.png"], ["", 102, "images/purplePrinceCropped.png"],
    ["", 112, "images/purpleGeneralCropped.png"], ["", 114, "images/purpleBishopCropped.png"],
    ["", 115, "images/purpleRookCropped.png"]];

/*The user hovers on this button to remind themself of what their piece will be changed to if
placed in one of the purple cells.*/
$("#showPurpleImgs").mouseenter(function(){
    //Stores what's in the purple cells and displays the purple images.
    for(let e = 0; e < purpleArr.length; e++){
        purpleArr[e][0] = $("#" + purpleArr[e][1] + " img").attr("src");
        $("#" + purpleArr[e][1] + " img").attr("src", purpleArr[e][2]);
    }
}).mouseleave(function(){
    //Restores what was in the purple cells before the hover.
    for(let l = 0; l < purpleArr.length; l++){
        $("#" + purpleArr[l][1] + " img").attr("src", purpleArr[l][0]);
    }
});