"use strict";
import {Game} from "./game.js";
let game = new Game();
$("td").click(function(){
    if(game.getClickTurn() == "pickUp"){
        game.pickUp(this);
    }
    else{
        game.putDown(this);
    }
});