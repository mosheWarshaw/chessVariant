"use strict";
export {pickUpRookOrBishop};
import {emptyAndNotOpaque} from "./emptyAndNotOpaque.js";
import {checkColor} from "./checkColor.js";
function pickUpRookOrBishop(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor){
    let tenOrTwelve;
    let oneOrEleven;
    let plusOrMinus;
    let secondCell;
    let secondCellsRed;
    let prevRed;
    let redMinusRed;
    let keepChecking;
    let plus = 1;
    let minus = -1;
    let secondCellsPiece;
    let colorPassesTest;
    let emptyAndNotOpaquePassesTest;
    let secondCellsPieceColor;

    /*this outer for loop will run the inner one 4 times. the inner for loop checks all the cells in a row,
    and this outer one has each of the 4 directions checked.
    the 4 directions are left to right, right to left, up to down, and down to up.
    the reason there's a left to right and a right to left (it's the same reason for having an up to down
    and a down to up) is because the way i check left to right is from the cell where the piece was to the leftmost
    cell in the row, and the way i check right to left is from the cell where the piece was to the rightmost cell.
    to understand why i do this think about the way a rook can move: it can move as far outward in a direction until
    the end of the row is reached unless a piece is in its way; so just because a piece can or cannot move in
    a direction, or how far it can move in one direction, does not effect at all how far it can move in the other
    direction.*/
    for(let i = 0; i < 4; i++){
        keepChecking = true;
        /*when the rook moves from left to right (it's simplest to understand when you look at the top row, which
         is 1 through 11 in blue),assuming it started in 1 blue and you want to move it one to the right you
         can add 11 to the first cell's red and you'd get the second cell's red. Each cell in the row is 11 away
         from the previous one. to reach a cell that is 2 spaces away, add 22 (this is 2 * 11) to the first cell to
         reach it. you can reach any cell in the row by adding 11 or by adding 11
         times a number between 1 and 10.
         to go from right to left you do the same thing except you subtract 11 instead of adding 11.
         Going from top to bottom and bottom to top is the same idea, but you use 1, not
         11, so for 2 of the iterations 11 is going to be used and 1 will be used the other 2 times(this is
         the oneOrEleven variable).
         every other iteration i'm either adding or subtracting. this is what the plusOrMinus is. iw will be multiplied
         by the number which will cause subtraction to be done when it's -1.
         the bishop is the same but it uses 10 or 12 instead of 1 or eleven.*/
        if(i < 2){
            tenOrTwelve = 10;
            oneOrEleven = 1;
        }
        else{
            tenOrTwelve = 12;
            oneOrEleven = 11;
        }
        if(i % 2 == 0){
            plusOrMinus = plus;
        }
        else{
            plusOrMinus = minus;
        }

        for (let c = 1; (c < 11) && keepChecking; c++){
            if(pickedUpPiece == "images/whiteRookCropped.png" || pickedUpPiece == "images/blackRookCropped.png"){
                secondCell = firstCellsBlue + (plusOrMinus * (c * oneOrEleven));
                prevRed = parseInt($("#" + (firstCellsBlue + (plusOrMinus * ((c - 1) * oneOrEleven)))).attr("title"));
            }
            else{
                secondCell = firstCellsBlue + (plusOrMinus * (c * tenOrTwelve));
                prevRed = parseInt($("#" + (firstCellsBlue + (plusOrMinus * ((c - 1) * tenOrTwelve)))).attr("title"));
            }
            secondCellsRed = parseInt($("#" + secondCell).attr("title"));
            redMinusRed = Math.abs(secondCellsRed - prevRed);
            if(redMinusRed > 90){
                keepChecking = false;
            }

            /*you need the loop to iterate the full 10 times to get 10 * 12
            in case the bishop is in cell 1, because it should be able to move to cell 121.
            however if you start in cell 50, for example, (or any number more than 1),
            the loop is checking cells that don't exist on the board. It's checking (10 * 12)
            plus 50; there is no cell 170, so the code would be told to stop checking this direction.*/
            if(secondCell > 121 || secondCell < 1){
                keepChecking = false;
            }

            if(keepChecking){
                secondCellsPiece = $("#" + secondCell + " img").attr("src");
                secondCellsPieceColor = $("#" + secondCell + " img").attr("class");
                colorPassesTest = checkColor(pickedUpPiecesColor, secondCellsPieceColor);
                emptyAndNotOpaquePassesTest = emptyAndNotOpaque(secondCell);
                /*if colorPassesTest then both if statements will run, meaning the cell will be given a  cyan border,
                but the rest of the cell's in this row and direction won't be checked.*/
                if(colorPassesTest || emptyAndNotOpaquePassesTest){
                    $("#" + secondCell).addClass("cyanBorder");
                    secondCellOptionsPar.push(secondCell);
                }
                if(colorPassesTest || (!colorPassesTest && !emptyAndNotOpaquePassesTest)){
                    keepChecking = false;
                }
            }
        }
    }
    return secondCellOptionsPar;
}