"use strict";
export { pickUpRookOrBishop };
import { emptyAndNotOpaque } from "./emptyAndNotOpaque.js";
import { checkColor } from "./checkColor.js";
function pickUpRookOrBishop(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor) {
  /*Each of the 4 functions are for checking the cells in a differnt direction. The 4 directions are
  left to right, right to left, up to down, and down to up.
  The reason there's a left to right and a right to left (it's the same reason for having an
  up to down and a down to up) is because the way I check left to right is from the cell where
  the piece was to the leftmost cell in the row, and the way I check right to left is from the
  cell where the piece was to the rightmost cell.
  To understand why I do this think about the way a rook or bishop can move: it can move as far outward
  in a direction until the end of the row is reached unless a piece is in its way; so just because
  a piece can or cannot move in a direction, or how far it can move in one direction, does not
  affect at all how far it can move in the other direction.*/

  /*When the rook moves from left to right (it's simplest to understand when you look at the
  top row, which is 1 through 11 in blue), assuming it started in 1 blue and you want to move
  it one to the right you can add 11 to the first cell's blue. Each cell in the row is 11 away
  from the previous one. To reach a cell that is 2 spaces away, add 22 (this is 2 * 11) to the first
  cell to reach it. You can reach any cell in the row by adding 11 or by adding 11 times a number
  between 1 and 10.
  To go from right to left you do the same thing except you subtract 11 instead of adding 11.
  Going from top to bottom and bottom to top is the same idea, but you use 1, not
  11. This is the what the cellDiff (short for cell difference (it's the difference between this cell and it's
  neighbr in a ceertain direction)) argument is.
  The bishop is the same, but it uses 10 and 12 instead
  of 1 and 11.
  posOrNeg takes care of adding and subtracting bby either being 1 or -1, respectvely. It
  will be multiplied by the number, which will cause subtraction if posOrNeg is -1.*/

  if (pickedUpPiece == "images/whiteRookCropped.png" || pickedUpPiece == "images/blackRookCropped.png") {
    secondCellOptionsPar = func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, 11, 1);
    secondCellOptionsPar = func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, 11, -1);
    secondCellOptionsPar = func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, 1, 1);
    secondCellOptionsPar = func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, 1, -1);
  }
  else { //picked up piece is bishop.
    secondCellOptionsPar = func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, 10, 1);
    secondCellOptionsPar = func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, 10, -1);
    secondCellOptionsPar = func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, 12, 1);
    secondCellOptionsPar = func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, 12, -1);
  }
  return secondCellOptionsPar;
}

function func(secondCellOptionsPar, firstCellsBlue, pickedUpPiece, pickedUpPiecesColor, cellDiff, posOrNeg) {
  let secondCell;
  let secondCellsRed;
  let prevRed;
  let redMinusRed;
  let colorPassesTest;
  let emptyAndNotOpaquePassesTest;
  let secondCellsPieceColor;
  let keepChecking = true;
  //'c' is for iterating through the 11 cells of a row.
  for (let c = 1; (c < 11) && keepChecking; c++) {
    if (pickedUpPiece == "images/whiteRookCropped.png" || pickedUpPiece == "images/blackRookCropped.png") {
      secondCell = firstCellsBlue + (posOrNeg * (c * cellDiff));
      prevRed = parseInt($("#" + (firstCellsBlue + (posOrNeg * ((c - 1) * cellDiff)))).attr("title"));
    }
    else {
      secondCell = firstCellsBlue + (posOrNeg * (c * cellDiff));
      prevRed = parseInt($("#" + (firstCellsBlue + (posOrNeg * ((c - 1) * cellDiff)))).attr("title"));
    }
    secondCellsRed = parseInt($("#" + secondCell).attr("title"));
    redMinusRed = Math.abs(secondCellsRed - prevRed);
    if (redMinusRed > 90) {
      keepChecking = false;
    }

    /*You need the loop to iterate the full 10 times to get 10 * 12
    in case the bishop is in cell 1, because it should be able to move to cell 121.
    However, if you start in cell 50, for example, (or any number more than 1),
    the loop is checking cells that don't exist on the board. It's checking (10 * 12)
    plus 50; there is no cell 170, so the code would be told to stop checking this direction
    once that happpens.*/
    if (secondCell > 121 || secondCell < 1) {
      keepChecking = false;
    }

    if (keepChecking) {
      secondCellsPieceColor = $("#" + secondCell + " img").attr("class");
      colorPassesTest = checkColor(pickedUpPiecesColor, secondCellsPieceColor);
      emptyAndNotOpaquePassesTest = emptyAndNotOpaque(secondCell);
      /*If colorPassesTest then both if statements will run, meaning the cell will be given a
      cyan border, but the rest of the cell's in this row and direction won't be checked.*/
      if (colorPassesTest || emptyAndNotOpaquePassesTest) {
        $("#" + secondCell).addClass("cyanBorder");
        secondCellOptionsPar.push(secondCell);
      }
      if (colorPassesTest || (!colorPassesTest && !emptyAndNotOpaquePassesTest)) {
        keepChecking = false;
      }
    }
  }
  return secondCellOptionsPar;
}